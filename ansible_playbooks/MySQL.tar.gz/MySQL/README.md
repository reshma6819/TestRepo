Purpose

This playbook will be used for creating MySQL 3 node InnoDB cluster.
